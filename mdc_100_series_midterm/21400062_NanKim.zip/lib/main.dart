
import 'package:flutter/material.dart';
import 'package:Shrine/app.dart';

void main() => runApp(ShrineApp());
